package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class index_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<!--\r\n  Licensed to the Apache Software Foundation (ASF) under one or more\r\n  contributor license agreements.  See the NOTICE file distributed with\r\n  this work for additional information regarding copyright ownership.\r\n  The ASF licenses this file to You under the Apache License, Version 2.0\r\n  (the \"License\"); you may not use this file except in compliance with\r\n  the License.  You may obtain a copy of the License at\r\n\r\n      http://www.apache.org/licenses/LICENSE-2.0\r\n\r\n  Unless required by applicable law or agreed to in writing, software\r\n  distributed under the License is distributed on an \"AS IS\" BASIS,\r\n  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.\r\n  See the License for the specific language governing permissions and\r\n  limitations under the License.\r\n-->\r\n<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\r\n<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"\r\n   \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">\r\n\r\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\">\r\n");
      out.write("    <head>\r\n    <title>");
      out.print( application.getServerInfo() );
      out.write("</title>\r\n    <style type=\"text/css\">\r\n    /*<![CDATA[*/\r\n      body {\r\n          color: #000000;\r\n          background-color: #FFFFFF;\r\n\t  font-family: Arial, \"Times New Roman\", Times, serif;\r\n          margin: 10px 0px;\r\n      }\r\n\r\n    img {\r\n       border: none;\r\n    }\r\n    \r\n    a:link, a:visited {\r\n        color: blue\r\n    }\r\n\r\n    th {\r\n        font-family: Verdana, \"Times New Roman\", Times, serif;\r\n        font-size: 110%;\r\n        font-weight: normal;\r\n        font-style: italic;\r\n        background: #D2A41C;\r\n        text-align: left;\r\n    }\r\n\r\n    td {\r\n        color: #000000;\r\n\tfont-family: Arial, Helvetica, sans-serif;\r\n    }\r\n    \r\n    td.menu {\r\n        background: #FFDC75;\r\n    }\r\n\r\n    .center {\r\n        text-align: center;\r\n    }\r\n\r\n    .code {\r\n        color: #000000;\r\n        font-family: \"Courier New\", Courier, monospace;\r\n        font-size: 110%;\r\n        margin-left: 2.5em;\r\n    }\r\n    \r\n     #banner {\r\n        margin-bottom: 12px;\r\n     }\r\n\r\n     p#congrats {\r\n         margin-top: 0;\r\n         font-weight: bold;\r\n");
      out.write("         text-align: center;\r\n     }\r\n\r\n     p#footer {\r\n         text-align: right;\r\n         font-size: 80%;\r\n     }\r\n     /*]]>*/\r\n   </style>\r\n</head>\r\n\r\n<body>\r\n\r\n<!-- Header -->\r\n<table id=\"banner\" width=\"100%\">\r\n    <tr>\r\n      <td align=\"left\" style=\"width:130px\">\r\n        <a href=\"http://tomcat.apache.org/\">\r\n\t  <img src=\"tomcat.gif\" height=\"92\" width=\"130\" alt=\"The Mighty Tomcat - MEOW!\"/>\r\n\t</a>\r\n      </td>\r\n      <td align=\"left\" valign=\"top\"><b>");
      out.print( application.getServerInfo() );
      out.write("</b></td>\r\n      <td align=\"right\">\r\n        <a href=\"http://www.apache.org/\">\r\n\t  <img src=\"asf-logo-wide.gif\" height=\"51\" width=\"537\" alt=\"The Apache Software Foundation\"/>\r\n\t</a>\r\n       </td>\r\n     </tr>\r\n</table>\r\n\r\n<table>\r\n    <tr>\r\n\r\n        <!-- Table of Contents -->\r\n        <td valign=\"top\">\r\n            <table width=\"100%\" border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\r\n                <tr>\r\n\t\t  <th>Administration</th>\r\n                </tr>\r\n                <tr>\r\n\t\t  <td class=\"menu\">\r\n\t\t    <a href=\"manager/status\">Status</a><br/>\r\n                    <a href=\"admin\">Tomcat&nbsp;Administration</a><br/>\r\n                    <a href=\"manager/html\">Tomcat&nbsp;Manager</a><br/>\r\n                    &nbsp;\r\n                  </td>\r\n                </tr>\r\n            </table>\r\n\r\n\t    <br />\r\n            <table width=\"100%\" border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\r\n                <tr>\r\n\t\t  <th>Documentation</th>\r\n                </tr>\r\n                <tr>\r\n                  <td class=\"menu\">\r\n                    <a href=\"RELEASE-NOTES.txt\">Release&nbsp;Notes</a><br/>\r\n");
      out.write("                    <a href=\"tomcat-docs/changelog.html\">Change&nbsp;Log</a><br/>\r\n                    <a href=\"tomcat-docs\">Tomcat&nbsp;Documentation</a><br/>                        &nbsp;\r\n                    &nbsp;\r\n\t\t    </td>\r\n                </tr>\r\n            </table>\r\n\t    \r\n            <br/>\r\n            <table width=\"100%\" border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\r\n                <tr>\r\n                  <th>Tomcat Online</th>\r\n                </tr>\r\n                <tr>\r\n                  <td class=\"menu\">\r\n                    <a href=\"http://tomcat.apache.org/\">Home&nbsp;Page</a><br/>\r\n\t\t    <a href=\"http://tomcat.apache.org/faq/\">FAQ</a><br/>\r\n                    <a href=\"http://tomcat.apache.org/bugreport.html\">Bug&nbsp;Database</a><br/>\r\n                    <a href=\"http://issues.apache.org/bugzilla/buglist.cgi?bug_status=UNCONFIRMED&amp;bug_status=NEW&amp;bug_status=ASSIGNED&amp;bug_status=REOPENED&amp;bug_status=RESOLVED&amp;resolution=LATER&amp;resolution=REMIND&amp;resolution=---&amp;bugidtype=include&amp;product=Tomcat+5&amp;cmdtype=doit&amp;order=Importance\">Open Bugs</a><br/>\r\n");
      out.write("                    <a href=\"http://mail-archives.apache.org/mod_mbox/tomcat-users/\">Users&nbsp;Mailing&nbsp;List</a><br/>\r\n                    <a href=\"http://mail-archives.apache.org/mod_mbox/tomcat-dev/\">Developers&nbsp;Mailing&nbsp;List</a><br/>\r\n                    <a href=\"irc://irc.freenode.net/#tomcat\">IRC</a><br/>\r\n\t\t    &nbsp;\r\n                  </td>\r\n                </tr>\r\n            </table>\r\n\t    \r\n            <br/>\r\n            <table width=\"100%\" border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\r\n                <tr>\r\n                  <th>Examples</th>\r\n                </tr>\r\n                <tr>\r\n                  <td class=\"menu\">\r\n                    <a href=\"jsp-examples/\">JSP&nbsp;Examples</a><br/>\r\n                    <a href=\"servlets-examples/\">Servlet&nbsp;Examples</a><br/>\r\n                    <a href=\"webdav/\">WebDAV&nbsp;capabilities</a><br/>\r\n     \t\t    &nbsp;\r\n                  </td>\r\n                </tr>\r\n            </table>\r\n\t    \r\n            <br/>\r\n            <table width=\"100%\" border=\"1\" cellspacing=\"0\" cellpadding=\"3\">\r\n");
      out.write("                <tr>\r\n\t\t  <th>Miscellaneous</th>\r\n                </tr>\r\n                <tr>\r\n                  <td class=\"menu\">\r\n                    <a href=\"http://java.sun.com/products/jsp\">Sun's&nbsp;Java&nbsp;Server&nbsp;Pages&nbsp;Site</a><br/>\r\n                    <a href=\"http://java.sun.com/products/servlet\">Sun's&nbsp;Servlet&nbsp;Site</a><br/>\r\n    \t\t    &nbsp;\r\n                  </td>\r\n                </tr>\r\n            </table>\r\n        </td>\r\n\r\n        <td style=\"width:20px\">&nbsp;</td>\r\n\t\r\n        <!-- Body -->\r\n        <td align=\"left\" valign=\"top\">\r\n          <p id=\"congrats\">If you're seeing this page via a web browser, it means you've setup Tomcat successfully. Congratulations!</p>\r\n \r\n          <p>As you may have guessed by now, this is the default Tomcat home page. It can be found on the local filesystem at:</p>\r\n          <p class=\"code\">$CATALINA_HOME/webapps/ROOT/index.jsp</p>\r\n\t  \r\n          <p>where \"$CATALINA_HOME\" is the root of the Tomcat installation directory. If you're seeing this page, and you don't think you should be, then either you're either a user who has arrived at new installation of Tomcat, or you're an administrator who hasn't got his/her setup quite right. Providing the latter is the case, please refer to the <a href=\"tomcat-docs\">Tomcat Documentation</a> for more detailed setup and administration information than is found in the INSTALL file.</p>\r\n");
      out.write("\r\n            <p><b>NOTE:</b> This page is precompiled. If you change it, this page will not change since\r\n                  it was compiled into a servlet at build time.\r\n                  (See <tt>$CATALINA_HOME/webapps/ROOT/WEB-INF/web.xml</tt> as to how it was mapped.)\r\n            </p>\r\n\r\n            <p><b>NOTE: For security reasons, using the administration webapp\r\n            is restricted to users with role \"admin\". The manager webapp\r\n            is restricted to users with role \"manager\".</b>\r\n            Users are defined in <code>$CATALINA_HOME/conf/tomcat-users.xml</code>.</p>\r\n\r\n            <p>Included with this release are a host of sample Servlets and JSPs (with associated source code), extensive documentation (including the Servlet 2.4 and JSP 2.0 API JavaDoc), and an introductory guide to developing web applications.</p>\r\n\r\n            <p>Tomcat mailing lists are available at the Tomcat project web site:</p>\r\n\r\n           <ul>\r\n               <li><b><a href=\"mailto:users@tomcat.apache.org\">users@tomcat.apache.org</a></b> for general questions related to configuring and using Tomcat</li>\r\n");
      out.write("               <li><b><a href=\"mailto:dev@tomcat.apache.org\">dev@tomcat.apache.org</a></b> for developers working on Tomcat</li>\r\n           </ul>\r\n\r\n            <p>Thanks for using Tomcat!</p>\r\n\r\n            <p id=\"footer\"><img src=\"tomcat-power.gif\" width=\"77\" height=\"80\" alt=\"Powered by Tomcat\"/><br/>\r\n\t    &nbsp;\r\n\r\n\t    Copyright &copy; 1999-2005 Apache Software Foundation<br/>\r\n            All Rights Reserved\r\n            </p>\r\n        </td>\r\n\r\n    </tr>\r\n</table>\r\n\r\n</body>\r\n</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
