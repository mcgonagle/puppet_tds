=======================================
   Alfresco 2.0 Polish Language Pack
	   March 06, 2007

 by: 
	Joanna Bardzinska
	Jaroslaw Pekala
	jaroslaw.pekala@winuel.com.pl
		
	WINUEL SA
	ul. Strzegomska 56a
	53-611 Wroclaw
	Poland
=======================================