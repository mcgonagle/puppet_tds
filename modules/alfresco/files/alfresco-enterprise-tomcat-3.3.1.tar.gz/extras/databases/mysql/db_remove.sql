drop database alfresco;
revoke all privileges, grant option from 'alfresco'@'localhost';
drop user 'alfresco'@'localhost';
